# SPEC-07: Deployment — Deploy em VPS

**Versão:** 1.0  
**Status:** Aprovado

---

## 1. REQUISITOS DA VPS

| Recurso | Mínimo | Recomendado |
|---|---|---|
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |
| CPU | 2 vCPUs | 4 vCPUs |
| RAM | 4 GB | 8 GB |
| Disco | 40 GB SSD | 80 GB SSD |
| Banda | 100 Mbps | 1 Gbps |
| IP | 1 IP fixo | 1 IP fixo |

**Providers sugeridos:** Hetzner (melhor custo-benefício), DigitalOcean, Vultr, Contabo

---

## 2. SCRIPT DE SETUP AUTOMÁTICO

```bash
#!/bin/bash
# scripts/setup_vps.sh
# Execute como root na VPS zerada

set -e  # Parar em caso de erro

echo "🚀 Iniciando setup do Nora Agent..."

# ──────────────────────────────────────
# 1. ATUALIZAR SISTEMA
# ──────────────────────────────────────
apt update && apt upgrade -y
apt install -y curl wget git nano ufw htop fail2ban

# ──────────────────────────────────────
# 2. INSTALAR DOCKER
# ──────────────────────────────────────
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker

# Instalar Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" \
    -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

echo "✅ Docker instalado: $(docker --version)"

# ──────────────────────────────────────
# 3. INSTALAR NGINX
# ──────────────────────────────────────
apt install -y nginx certbot python3-certbot-nginx
systemctl enable nginx

# ──────────────────────────────────────
# 4. CONFIGURAR FIREWALL (UFW)
# ──────────────────────────────────────
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 8080/tcp  # Evolution API (temporário, remover após configurar Nginx)
ufw --force enable

echo "✅ Firewall configurado"

# ──────────────────────────────────────
# 5. CONFIGURAR FAIL2BAN
# ──────────────────────────────────────
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
EOF
systemctl restart fail2ban

# ──────────────────────────────────────
# 6. CLONAR REPOSITÓRIO
# ──────────────────────────────────────
git clone https://github.com/seu-usuario/nora-agent.git /opt/nora-agent
cd /opt/nora-agent

# ──────────────────────────────────────
# 7. CONFIGURAR VARIÁVEIS DE AMBIENTE
# ──────────────────────────────────────
cp config/.env.example .env
echo ""
echo "⚠️  ATENÇÃO: Edite o arquivo .env antes de continuar!"
echo "   nano /opt/nora-agent/.env"
echo ""
read -p "Pressione ENTER após editar o .env..."

# ──────────────────────────────────────
# 8. SUBIR CONTAINERS
# ──────────────────────────────────────
docker-compose up -d

echo "⏳ Aguardando containers iniciarem..."
sleep 15

# ──────────────────────────────────────
# 9. CONFIGURAR SSL (HTTPS)
# ──────────────────────────────────────
read -p "Seu domínio (ex: nora.residencial.com.br): " DOMAIN

# Configurar Nginx
cat > /etc/nginx/sites-available/nora-agent << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /evolution/ {
        proxy_pass http://localhost:8080/;
        proxy_set_header Host \$host;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOF

ln -sf /etc/nginx/sites-available/nora-agent /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# Gerar certificado SSL
certbot --nginx -d $DOMAIN --non-interactive --agree-tos -m admin@$DOMAIN

echo "✅ SSL configurado para $DOMAIN"

# ──────────────────────────────────────
# 10. POPULAR BASE DE CONHECIMENTO
# ──────────────────────────────────────
echo ""
echo "📚 Populando base de conhecimento..."
echo "   Coloque seus PDFs em /opt/nora-agent/knowledge_docs/"
echo "   Depois execute: docker exec nora-app python scripts/seed_knowledge.py"

echo ""
echo "✅ ══════════════════════════════════════"
echo "✅  Nora Agent instalado com sucesso!"
echo "✅  URL: https://$DOMAIN"
echo "✅  Webhook: https://$DOMAIN/webhook/whatsapp"
echo "✅ ══════════════════════════════════════"
```

---

## 3. DOCKER COMPOSE COMPLETO

```yaml
# docker-compose.yml
version: '3.8'

services:
  # ─── Aplicação Nora ─────────────────────────
  nora-app:
    build: .
    container_name: nora_app
    restart: always
    ports:
      - "8000:8000"
    environment:
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - SUPABASE_URL=${SUPABASE_URL}
      - SUPABASE_SERVICE_KEY=${SUPABASE_SERVICE_KEY}
      - EVOLUTION_API_URL=http://evolution-api:8080
      - EVOLUTION_API_KEY=${EVOLUTION_API_KEY}
      - EVOLUTION_INSTANCE=${EVOLUTION_INSTANCE}
      - REDIS_URL=redis://redis:6379
    depends_on:
      - redis
      - evolution-api
    volumes:
      - ./knowledge_docs:/app/knowledge_docs
      - ./logs:/app/logs
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # ─── Evolution API (WhatsApp) ───────────────
  evolution-api:
    image: atendai/evolution-api:v2.2.3
    container_name: evolution_api
    restart: always
    ports:
      - "8080:8080"
    environment:
      - SERVER_URL=https://${DOMAIN}
      - AUTHENTICATION_API_KEY=${EVOLUTION_API_KEY}
      - WEBHOOK_GLOBAL_URL=https://${DOMAIN}/webhook/whatsapp
      - WEBHOOK_GLOBAL_ENABLED=true
      - WEBHOOK_EVENTS_MESSAGES_UPDATE=true
      - STORE_MESSAGES=true
      - STORE_MESSAGE_UP=true
    volumes:
      - evolution_data:/evolution/instances

  # ─── Redis (Fila de mensagens) ──────────────
  redis:
    image: redis:7-alpine
    container_name: nora_redis
    restart: always
    command: redis-server --appendonly yes --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data

volumes:
  evolution_data:
  redis_data:
```

---

## 4. DOCKERFILE

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Instalar dependências do sistema
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Instalar dependências Python
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código
COPY src/ ./src/
COPY config/ ./config/
COPY scripts/ ./scripts/

# Usuário não-root
RUN useradd -m -u 1000 nora && chown -R nora:nora /app
USER nora

EXPOSE 8000

CMD ["uvicorn", "src.api.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

---

## 5. REQUIREMENTS.TXT

```txt
# requirements.txt
anthropic==0.40.0
fastapi==0.115.0
uvicorn[standard]==0.32.0
supabase==2.10.0
httpx==0.27.2
redis==5.2.0
python-dotenv==1.0.1
pdfplumber==0.11.4
openai==1.55.0         # Para embeddings text-embedding-3-small
numpy==1.26.4
pydantic==2.10.0
pydantic-settings==2.6.0
```

---

## 6. MONITORAMENTO E MANUTENÇÃO

```bash
# Ver logs em tempo real
docker logs -f nora_app

# Reiniciar serviços
docker-compose restart nora-app

# Ver status de todos os containers
docker-compose ps

# Atualizar aplicação
cd /opt/nora-agent
git pull origin main
docker-compose up -d --build nora-app

# Backup do banco (via Supabase Dashboard)
# Supabase faz backup automático diário — verificar no painel

# Verificar uso de recursos
docker stats
```

---

## 7. CHECKLIST DE GO-LIVE

```
PRÉ-DEPLOY:
□ VPS configurada com Ubuntu 22.04
□ Domínio apontado para IP da VPS
□ Arquivo .env preenchido com todas as chaves
□ PDFs do regimento/regulamento disponíveis

DEPLOY:
□ script setup_vps.sh executado com sucesso
□ Todos os containers rodando (docker-compose ps)
□ SSL ativo (https:// funcionando)
□ Webhook da Evolution API configurado
□ Base de conhecimento populada (seed_knowledge.py)

PÓS-DEPLOY:
□ Testar onboarding com número novo
□ Testar fluxo de manutenção
□ Testar reserva de espaço
□ Testar broadcast de aviso
□ Testar detecção de emergência
□ Verificar logs sem erros (docker logs nora_app)
□ Confirmar que síndico recebe notificações urgentes
□ Enviar mensagem de apresentação no grupo do condomínio
```
